
  # AI Chatbot for Financial Planning

  This is a code bundle for AI Chatbot for Financial Planning. The original project is available at https://www.figma.com/design/69obX2OnUmTlHBgpijCZLN/AI-Chatbot-for-Financial-Planning.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  