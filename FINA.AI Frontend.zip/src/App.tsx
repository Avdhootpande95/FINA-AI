import React, { useState } from 'react';
import { HomePage } from './components/HomePage';
import { ChatInterface } from './components/ChatInterface';

export default function App() {
  const [currentPage, setCurrentPage] = useState<'home' | 'chat'>('home');

  const handleStartChat = () => {
    setCurrentPage('chat');
  };

  const handleGoHome = () => {
    setCurrentPage('home');
  };

  return (
    <div className="size-full">
      {currentPage === 'home' ? (
        <HomePage onStartChat={handleStartChat} />
      ) : (
        <ChatInterface onGoHome={handleGoHome} />
      )}
    </div>
  );
}