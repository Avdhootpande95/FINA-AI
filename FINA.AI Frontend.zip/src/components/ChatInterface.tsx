import React, { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { ScrollArea } from './ui/scroll-area';
import { Bot, Send, Home, RotateCcw } from 'lucide-react';

interface Message {
  id: string;
  content: string;
  isBot: boolean;
  timestamp: Date;
}

interface ChatInterfaceProps {
  onGoHome: () => void;
}

export function ChatInterface({ onGoHome }: ChatInterfaceProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      content: "I am your finance assistant bot.\n\nDisclaimer - I'm just an AI assistant providing financial guidance; this is a prediction for an ideal-case scenario, investments carry risks, and you should consult a licensed financial advisor before acting.",
      isBot: true,
      timestamp: new Date()
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  // Mock AI responses based on financial topics
  const getAIResponse = (userMessage: string): string => {
    const message = userMessage.toLowerCase();
    
    if (message.includes('budget') || message.includes('budgeting')) {
      return "For effective budgeting, I recommend the 50/30/20 rule: 50% of income for needs, 30% for wants, and 20% for savings and debt repayment. Start by tracking your expenses for a month to understand your spending patterns. Would you like me to help you create a specific budget plan?";
    }
    
    if (message.includes('invest') || message.includes('investment') || message.includes('stock')) {
      return "Investment strategies depend on your risk tolerance, timeline, and goals. For beginners, consider starting with diversified index funds or ETFs. A common approach is to invest in a mix of stocks (60-80%) and bonds (20-40%). Dollar-cost averaging can help reduce timing risk. What's your investment timeline and risk tolerance?";
    }
    
    if (message.includes('retirement') || message.includes('401k') || message.includes('ira')) {
      return "Retirement planning should start as early as possible due to compound interest. Aim to save 10-15% of your income for retirement. Take advantage of employer 401(k) matching if available - it's free money! Consider maxing out IRA contributions ($6,500 for 2023, $7,500 if 50+). What's your current age and retirement savings situation?";
    }
    
    if (message.includes('debt') || message.includes('credit card') || message.includes('loan')) {
      return "For debt management, prioritize high-interest debt first (avalanche method) or start with smallest balances (snowball method) for motivation. Pay minimums on all debts, then put extra money toward your target debt. Consider debt consolidation if it lowers your interest rate. What types of debt are you dealing with?";
    }
    
    if (message.includes('emergency fund') || message.includes('savings')) {
      return "An emergency fund should cover 3-6 months of living expenses. Keep this in a high-yield savings account for easy access. Start with a goal of $1,000, then build up gradually. This fund protects you from unexpected expenses and prevents you from going into debt. How much do you currently have in emergency savings?";
    }
    
    if (message.includes('house') || message.includes('mortgage') || message.includes('buying')) {
      return "When buying a house, aim for a down payment of at least 10-20% to avoid PMI. Your total housing costs shouldn't exceed 28% of gross income. Get pre-approved for a mortgage to understand your budget. Consider all costs: down payment, closing costs, moving expenses, and ongoing maintenance. Are you a first-time homebuyer?";
    }

    // Default response
    return "That's a great question! I can help you with various financial topics including budgeting, investing, retirement planning, debt management, and savings strategies. Could you be more specific about what aspect of your finances you'd like to discuss? I'm here to provide guidance tailored to your situation.";
  };

  const scrollToBottom = () => {
    // Use a timeout to ensure the DOM has updated
    setTimeout(() => {
      const scrollContainer = document.querySelector('[data-radix-scroll-area-viewport]');
      if (scrollContainer) {
        scrollContainer.scrollTop = scrollContainer.scrollHeight;
      }
    }, 100);
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      content: inputValue,
      isBot: false,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsTyping(true);

    // Simulate AI thinking time
    setTimeout(() => {
      const botResponse: Message = {
        id: (Date.now() + 1).toString(),
        content: getAIResponse(inputValue),
        isBot: true,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, botResponse]);
      setIsTyping(false);
    }, 1000 + Math.random() * 2000); // 1-3 seconds delay
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const clearChat = () => {
    setMessages([
      {
        id: '1',
        content: "I am your finance assistant bot.\n\nDisclaimer - I'm just an AI assistant providing financial guidance; this is a prediction for an ideal-case scenario, investments carry risks, and you should consult a licensed financial advisor before acting.",
        isBot: true,
        timestamp: new Date()
      }
    ]);
  };

  return (
    <div className="h-screen flex flex-col bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-primary p-2 rounded-lg">
              <Bot className="w-6 h-6 text-primary-foreground" />
            </div>
            <h1 className="text-xl">Fina AI Chat</h1>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={clearChat}>
              <RotateCcw className="w-4 h-4 mr-2" />
              New Chat
            </Button>
            <Button variant="outline" size="sm" onClick={onGoHome}>
              <Home className="w-4 h-4 mr-2" />
              Back to Start
            </Button>
          </div>
        </div>
      </header>

      {/* Chat Area */}
      <div className="flex-1 flex flex-col bg-secondary/30">
        <ScrollArea className="flex-1 p-4">
          <div className="max-w-4xl mx-auto space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex gap-3 ${message.isBot ? 'justify-start' : 'justify-end'}`}
              >
                {message.isBot && (
                  <div className="bg-primary p-2 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0">
                    <Bot className="w-4 h-4 text-primary-foreground" />
                  </div>
                )}
                <div
                  className={`max-w-[70%] p-3 rounded-lg ${
                    message.isBot
                      ? 'bg-muted text-foreground'
                      : 'bg-primary text-primary-foreground'
                  }`}
                >
                  <p className="whitespace-pre-wrap">{message.content}</p>
                  <p className={`text-xs mt-1 opacity-70`}>
                    {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
                {!message.isBot && (
                  <div className="bg-secondary p-2 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0">
                    <span className="text-secondary-foreground text-sm">You</span>
                  </div>
                )}
              </div>
            ))}
            
            {isTyping && (
              <div className="flex gap-3 justify-start">
                <div className="bg-primary p-2 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0">
                  <Bot className="w-4 h-4 text-primary-foreground" />
                </div>
                <div className="bg-muted text-foreground p-3 rounded-lg">
                  <div className="flex items-center gap-1">
                    <span>Assistant is typing</span>
                    <div className="flex gap-1">
                      <div className="w-1 h-1 bg-current rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                      <div className="w-1 h-1 bg-current rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                      <div className="w-1 h-1 bg-current rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </ScrollArea>

        {/* Input Area */}
        <div className="border-t border-border p-4">
          <div className="max-w-4xl mx-auto">
            <div className="flex gap-2">
              <Input
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Ask me about budgeting, investments, retirement planning..."
                className="flex-1"
                disabled={isTyping}
              />
              <Button 
                onClick={handleSendMessage} 
                disabled={!inputValue.trim() || isTyping}
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
            
            {/* Disclaimer */}
            <div className="mt-3 text-xs text-muted-foreground text-center">
              I'm just an AI assistant providing financial guidance; this is a prediction for an ideal-case scenario, investments carry risks, and you should consult a licensed financial advisor before acting.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}