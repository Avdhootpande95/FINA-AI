import React from 'react';
import { Button } from './ui/button';
import { Bot } from 'lucide-react';

interface HomePageProps {
  onStartChat: () => void;
}

export function HomePage({ onStartChat }: HomePageProps) {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Main Content */}
      <main className="flex-1 flex flex-col justify-center items-center px-4 py-16">
        <div className="text-center max-w-4xl mx-auto">
          {/* Large prominent title */}
          <h1 className="text-6xl font-bold mb-6 text-foreground">Fina AI</h1>
          
          {/* Welcome subtitle */}
          <p className="text-2xl mb-12 text-foreground max-w-3xl mx-auto leading-relaxed">
            Welcome to your AI financial advisor. Get personalized guidance for budgeting, investing, and planning your financial future.
          </p>
          
          {/* Single large Start Chat button */}
          <Button 
            onClick={onStartChat}
            size="lg"
            className="text-xl px-12 py-8 bg-primary text-primary-foreground hover:opacity-90 transition-opacity"
          >
            Start Chat
          </Button>
        </div>
      </main>

      {/* Disclaimer at bottom */}
      <footer className="bg-card/50 p-6 border-t border-border">
        <p className="text-sm text-center text-foreground max-w-4xl mx-auto">
          <strong>Disclaimer:</strong> I'm just an AI assistant providing financial guidance; this is a prediction for an ideal-case scenario, investments carry risks, and you should consult a licensed financial advisor before acting.
        </p>
      </footer>
    </div>
  );
}